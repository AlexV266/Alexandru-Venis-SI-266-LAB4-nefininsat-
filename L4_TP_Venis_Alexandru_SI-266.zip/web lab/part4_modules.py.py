#lab 4 partea a 4-a

import re
import ssl
import json
import socket
import hashlib
import requests
from datetime import datetime
import urllib.parse
from html.parser import HTMLParser

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

#35
p = urllib.parse.urlparse("https://cybercor.org/path?x=1#top")
print("Scheme:", p.scheme)
print("Netloc:", p.netloc)
print("Path:", p.path)
print("Query:", p.query)
print("Fragment:", p.fragment)

#ex36
legături = ["/about", "contact.html", "../index.html"]
for l in legături:
    full = urllib.parse.urljoin(BASE_URL, l)
    print("URL complet:", full)

#exercitiu37
def extract_links(html):
    """Extrage toate legăturile href din codul HTML."""
    gasite = re.findall(r'href="([^"]+)"', html)
    return list(set(gasite))

# 38
def split_links(links, domain):
    """Desparte legăturile în interne și externe."""
    interne = []
    externe = []
    for l in links:
        full = urllib.parse.urljoin("https://" + domain, l)
        parsed = urllib.parse.urlparse(full)
        if parsed.netloc == domain or not parsed.netloc:
            interne.append(full)
        else:
            externe.append(full)
    return interne, externe

# ex39
class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            attrs_dict = dict(attrs)
            src = attrs_dict.get("src")
            if src:
                self.images.append(src)

test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://i.pinimg.com/474x/ff/a4/44/ffa4444b05e3cad5c75ba0a418bda7d4.jpg" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp",
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

#ex40
def page_fingerprint(url):
    """Calculează amprenta SHA256 a conținutului paginii."""
    res = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(res.content).hexdigest()

print("Fingerprint 1:", page_fingerprint(BASE_URL))
print("Fingerprint 2:", page_fingerprint(BASE_URL))


#exercitiu 41
res = requests.get(BASE_URL, timeout=TIMEOUT)
with open("headers.json", "w", encoding="utf-8") as f:
    json.dump(dict(res.headers), f, indent=2)

with open("headers.json", "r", encoding="utf-8") as f:
    date_salvate = json.load(f)
    print("Header salvat:", date_salvate.get("Content-Type"))

#exercitiu 42
def resolve(hostname):
    """Află adresa IP pentru un nume de domeniu."""
    return socket.gethostbyname(hostname)

print("IP cybercor.org:", resolve("cybercor.org"))

# exercitiu 43
def cert_days_left(hostname):
    """Verifică câte zile au mai rămas până la expirarea certificatului SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            exp_date_str = cert["notAfter"]
            exp_date = datetime.strptime(exp_date_str, "%b %d %H:%M:%S %Y %Z")
            zile = (exp_date - datetime.utcnow()).days
            return zile

print("SSL zile ramase:", cert_days_left("cybercor.org"))

