#lab 4 partea a 5-a
import ssl
import json
import socket
import requests
import urllib.parse
from datetime import datetime

#ex47
DEFAULT_HEADERS = {"User-Agent": "WebLab-Venis Alexandru(sefu)"}
TIMEOUT = 10

#ex44
def fetch(url):
    """cerere get"""
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=TIMEOUT)

def get_status(url):
    """returnea codului http pentru url"""
    try:
        res = fetch(url)
        return res.status_code
    except requests.RequestException:
        return 0

def get_title(html):
    """titlul din html"""
    start = html.find("<title>")
    end = html.find("</title>")
    if start != -1 and end != -1:
        return html[start + len("<title>"):end].strip()
    return "Fără titlu"

def security_headers(url):
    """verifica 5 antete de securitate"""
    antete = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    try:
        res = fetch(url)
        return {h: h in res.headers for h in antete}
    except requests.RequestException:
        return {h: False for h in antete}

def score_headers(results):
    """returnează scorul antetelor găsite sb formă de text"""
    prezente = sum(1 for v in results.values() if v)
    return f"{prezente}/{len(results)}"

def resolve(hostname):
    """Află adresa IP pentru un nume de domeniu"""
    try:
        return socket.gethostbyname(hostname)
    except Exception:
        return "N/A"

def cert_days_left(hostname):
    """calculeaza cit mai are ssl pina la expirare"""
    try:
        context = ssl.create_default_context()
        with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                exp_date = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z")
                return (exp_date - datetime.utcnow()).days
    except Exception:
        return 0

def fetch_robots(base):
    """Returnează conținutul fișierului robots.txt."""
    try:
        res = fetch(base + "/robots.txt")
        if res.status_code == 200:
            return res.text
        return None
    except requests.RequestException:
        return None

def disallowed_paths(robots_text):
    """Extrage căile interzise din robots.txt."""
    if not robots_text:
        return []
    rezultat = []
    for linie in robots_text.splitlines():
        if linie.strip().startswith("Disallow:"):
            parti = linie.split(":", 1)
            if len(parti) > 1 and parti[1].strip():
                rezultat.append(parti[1].strip())
    return rezultat

def extract_links(html):
    """Extrage toate legăturile href dintr-un șir HTML."""
    import re
    return list(set(re.findall(r'href="([^"]+)"', html)))

def split_links(links, domain):
    """Desparte legăturile în interne și externe."""
    interne, externe = [], []
    for l in links:
        full = urllib.parse.urljoin("https://" + domain, l)
        parsed = urllib.parse.urlparse(full)
        if parsed.netloc == domain or not parsed.netloc:
            interne.append(full)
        else:
            externe.append(full)
    return interne, externe

def check_paths(base, paths):
    """Verifică o listă de căi și returnează un dicționar cu statusurile lor."""
    rezultate = {}
    for p in paths:
        full_url = base + p
        try:
            res = fetch(full_url)
            rezultate[p] = res.status_code
        except requests.RequestException:
            rezultate[p] = 0
    return rezultate

# ex50(in partea urmatoare tot dupa idee va trebuie sa fie ca final)
def site_report(url):
    """Generează raportul detaliat al site-ului și îl salvează în report.json."""
    parsed = urllib.parse.urlparse(url)
    domain = parsed.netloc or parsed.path

    res = fetch(url)
    status = res.status_code
    final_url = res.url
    titlu = get_title(res.text)
    ip = resolve(domain)

    # verificare simpla de http
    http_url = f"http://{domain}"
    try:
        res_redir = requests.get(http_url, timeout=TIMEOUT)
        redir_str = " -> ".join([str(r.status_code) for r in res_redir.history]) if res_redir.history else "Fără redirecționări"
    except Exception:
        redir_str = "N/A"

    sec_score = score_headers(security_headers(url))
    zile_cert = cert_days_left(domain)

    links = extract_links(res.text)
    interne, externe = split_links(links, domain)

    robots = fetch_robots(f"https://{domain}")
    interzise = disallowed_paths(robots)

    raport = {
        "status_code": status,
        "final_url": final_url,
        "title": titlu,
        "ip": ip,
        "redirects": redir_str,
        "security_score": sec_score,
        "cert_days_left": zile_cert,
        "internal_links": len(interne),
        "external_links": len(externe),
        "disallowed_paths": interzise
    }

    
    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare:      {status}")
    print(f"Titlu:             {titlu}")
    print(f"Adresă IP:         {ip}")
    print(f"Redirecționări:    {redir_str}")
    print(f"Scor securitate:   {sec_score}")
    print(f"Certificat:        {zile_cert} de zile rămase")
    print(f"Legături:          {len(interne)} interne, {len(externe)} externe")
    print(f"Căi interzise:     {', '.join(interzise[:5]) if interzise else 'Niciuna'}")

    
    with open("report.json", "w", encoding="utf-8") as f:
        json.dump(raport, f, indent=2)
    print("Salvat în report.json")

#ex46 (in teorie blocul main ar trebui sa se ruleze de la acest fisier,sper...)
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))