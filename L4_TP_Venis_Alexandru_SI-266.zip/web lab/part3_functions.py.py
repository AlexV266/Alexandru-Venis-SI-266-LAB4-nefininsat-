#partea 3 lab4

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 

# ex21
def fetch(url):
    """Efectuează o cerere GET și returnează obiectul response."""
    return requests.get(url, timeout=TIMEOUT)

print("Ex21 status:", fetch(BASE_URL).status_code)

#ex22
def get_status(url):
    """Returneaza codul de stare HTTP pentru adrsa url"""
    res = requests.get(url, timeout=TIMEOUT)
    return res.status_code

time.sleep(1)
print("Status /:", get_status(BASE_URL + "/"))
time.sleep(1)
print("Status /robots.txt:", get_status(BASE_URL + "/robots.txt"))
time.sleep(1)
print("Status /sitemap.xml:", get_status(BASE_URL + "/sitemap.xml"))

#exercitiu 23
def fetch_timeout(url, timeout=10):
    """Afișează o cerere cu timeout configurabil."""
    return requests.get(url, timeout=timeout)

res_def = fetch_timeout(BASE_URL)
res_cust = fetch_timeout(BASE_URL, timeout=3)

# exercitiu24
def get_title(html):
    """Extrage titlul dintr-un șir de text HTML."""
    start = html.find("<title>")
    end = html.find("</title>")
    if start != -1 and end != -1:
        return html[start + len("<title>"):end].strip()
    return "Fără titlu"

# exercitiul 25
help(get_title)

# Exercițiul 26
def get_status_typed(url: str) -> int:
    """Returnează codul de stare HTTP folosind adnotări de tip."""
    res = requests.get(url, timeout=TIMEOUT)
    return res.status_code



# exercitiul 27
def page_exists(url):
    """Verifică dacă o pagină există fără să oprească programul cu eroare."""
    try:
        res = requests.get(url, timeout=TIMEOUT)
        return res.status_code == 200
    except requests.RequestException:
        return False

print("Pagină invalidă există?:", page_exists("https://this-domain-does-not-exist.invalid"))

#ex28
def check_paths(base, paths):
    """Verifică o listă de căi relative și returnează un dicționar cu statusurile lor."""
    rezultate = {}
    for p in paths:
        full_url = base + p
        try:
            res = requests.get(full_url, timeout=TIMEOUT)
            rezultate[p] = res.status_code
        except requests.RequestException:
            rezultate[p] = 0
        time.sleep(1)
    return rezultate

# ex29
def get_header(url, name, default="lipsește"):
    """Returnează valoarea unui singur antet dintr-o cerere."""
    try:
        res = requests.get(url, timeout=TIMEOUT)
        return res.headers.get(name, default)
    except requests.RequestException:
        return default

print("Server Header:", get_header(BASE_URL, name="Server"))

#ex30
def security_headers(url):
    """Verifică prezența celor 5 antete de securitate principale."""
    antete_căutate = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    try:
        res = requests.get(url, timeout=TIMEOUT)
        return {h: h in res.headers for h in antete_căutate}
    except requests.RequestException:
        return {h: False for h in antete_căutate}

#ex31
def score_headers(results):
    """Returnează scorul antetelor găsite sub formă de text (ex: 3/5)."""
    prezente = sum(1 for val in results.values() if val)
    total = len(results)
    return f"{prezente}/{total}"

print("Scor securitate:", score_headers(security_headers(BASE_URL)))

# ex32
def fetch_robots(base):
    """Returnează conținutul fișierului robots.txt."""
    try:
        res = requests.get(base + "/robots.txt", timeout=TIMEOUT)
        if res.status_code == 200:
            return res.text
        return None
    except requests.RequestException:
        return None

def disallowed_paths(robots_text):
    """Extrage căile interzise din robots.txt."""
    if not robots_text:
        return []
    linii = robots_text.splitlines()
    rezultat = []
    for linie in linii:
        if linie.strip().startswith("Disallow:"):
            părti = linie.split(":", 1)
            if len(părti) > 1:
                cale = părti[1].strip()
                if cale:
                    rezultat.append(cale)
    return rezultat

#ex33
def response_times(*urls):
    """Măsoară timpul de răspuns pentru oricâte URL-uri primite."""
    timpi = {}
    for url in urls:
        try:
            t1 = time.perf_counter()
            requests.get(url, timeout=TIMEOUT)
            t2 = time.perf_counter()
            timpi[url] = round(t2 - t1, 3)
        except requests.RequestException:
            timpi[url] = -1
        time.sleep(1)
    return timpi

# ex34
def log(message, **details):
    """Afișează un mesaj formatat împreună cu detaliile primite."""
    detalii_str = " | ".join([f"{k}={v}" for k, v in details.items()])
    if detalii_str:
        print(f"{message} | {detalii_str}")
    else:
        print(message)

log("verificat", url=BASE_URL, status=200)

