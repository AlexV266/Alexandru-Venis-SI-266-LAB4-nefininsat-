# lab 4 facut de Venis Alexandru SI-266

import time
import requests
import urllib.request

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#1
print("Versiune requests:", requests.__version__)
#este nevoie de pip install ca request este o biblioteca externa


#2
res1 = requests.get(BASE_URL, timeout=TIMEOUT)
print("Status cu requests.get:", res1.status_code)
#scirem import requests ca sa fie de inteles de unde vine fucntia (speram)

from requests import get
res2 = get(BASE_URL, timeout=TIMEOUT)
print("Status cu import get:", res2.status_code)
##scirem import requests ca sa fie de inteles de unde importam fucntia

#ex3

import requests as rq
res3 = rq.get(BASE_URL, timeout=TIMEOUT)
print("Status cu alias rq:", res3.status_code)
# sa fie mai usor cind modulul are denumire grea sau lunga

#exercitiul 4
with urllib.request.urlopen(BASE_URL) as response:
    status_code = response.status
    body_bytes = response.read()
    body_text = body_bytes.decode("utf-8")
    print("Urllib status:", status_code)
    print("Primele 200 caractere:", body_text[:200])

#ex 5
print(dir(requests))


#ex6

#punem parametru pentru timpul de asteptare
res_timeout = requests.get(BASE_URL, timeout=5)

# Ex 7
t1 = time.perf_counter()
res_time = requests.get(BASE_URL, timeout=TIMEOUT)
t2 = time.perf_counter()
durata_masurata = t2 - t1
print(f"Timp masurat cu perf_counter: {durata_masurata:.4f}s")
print(f"Timp din response.elapsed: {res_time.elapsed.total_seconds():.4f}s")

# Exercitiul 8
try:
    import bs4
except ImportError:
    print("Instalati modulul cu: pip install beautifulsoup4")