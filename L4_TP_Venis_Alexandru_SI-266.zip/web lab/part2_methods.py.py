#lab 4 partea 2

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  

# ex9
res = requests.get(BASE_URL, timeout=TIMEOUT)
print("status_code:", res.status_code)  #salveaza numarul
print("ok:", res.ok)                    #atribuie daca e adevarat sau fals
print("url:", res.url)                  #atribuie sirul de caractre
print("encoding:", res.encoding)        #codica textul

#ex10
try:
    res.raise_for_status()
    res_bad = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    res_bad.raise_for_status()
except requests.HTTPError as e:
    print("Pagina nu a fost gasita sau a aprut o eroare HTTP:", e)

#ex11
time.sleep(1)
print("\n--- Antete ---")
for key, val in res.headers.items():
    print(f"{key}: {val}")

#ex12
server_hdr = res.headers.get("Server", "lipseste")
content_type_hdr = res.headers.get("Content-Type", "lipseste")
content_type_lower = res.headers.get("content-type", "lipsesfte")
print("Server:", server_hdr)
print("Content-Type:", content_type_hdr)
print("content-type (cu mici):", content_type_lower)
# dictionarul din  din request nu este sensibil la litere mici

#ex13
apariții_cyber = res.text.lower().count("cyber")
print("Cuvântul 'cyber' apare de:", apariții_cyber, "ori")
# sunt legate ca lower da acelasi rezultat care poate fi numarat 

#ex14
html = res.text
start_idx = html.find("<title>") + len("<title>")
end_idx = html.find("</title>")
if start_idx != -1 and end_idx != -1:
    titlu = html[start_idx:end_idx].strip()
    print("Titlu extras:", titlu)

# ex 15
linii = html.splitlines()
print("Număr total de linii:", len(linii))
dacă_linii:
    cea_mai_lungă = max(linii, key=len)
    print("Lungimea a celei mai lungi linii:", len(cea_mai_lungă))

#ex16
if res.url.startswith("https://"):
    print("Conexiunea este nescuriznata")
else:
    print("Conexiunea  este nesecurizata")

# ex17
time.sleep(1)
res_redir = requests.get("http://cybercor.org", timeout=TIMEOUT)
print("\n--- Lanț redirecționări ---")
for resp in res_redir.history:
    print(resp.status_code, "->", resp.url)
print("URL final:", res_redir.url)

#ex18
time.sleep(1)
res_head = requests.head(BASE_URL, timeout=TIMEOUT)
res_get = requests.get(BASE_URL, timeout=TIMEOUT)
print("HEAD len content:", len(res_head.content))
print("GET len content:", len(res_get.content))
#head aduce datele si get descarca

#ex19
if len(res.cookies) == 0:
    print("Niciun cookie setat")
else:
    for c in res.cookies:
        print("Cookie:", c.name, "| Secure:", c.secure)

# ex20
s = requests.Session()
s.headers.update({"User-Agent": "WebLab-Veniș Alexandru"})
res_sess = s.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print("Rezultat sesiune user-agent:", res_sess.json().get("headers", {}).get("User-Agent"))

# textul e atribut este o valoare, iar json este o functie.