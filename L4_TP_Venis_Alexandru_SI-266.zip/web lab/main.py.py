#lab4 partea a-6a file principal

import csv
import argparse
from datetime import datetime
import webtools

# ex45, importarea din modul scris inainte
from webtools import get_title, security_headers
_ = (get_title, security_headers)

# ex47 (ex46 era facut precedent)
print("Constantă importată:", webtools.DEFAULT_HEADERS)

# ex 48 argumentatia din linia de comanda
parser = argparse.ArgumentParser(description="Analizor site web")
parser.add_argument("url", nargs="?", default="https://cybercor.org", help="URL-ul site-ului")
args = parser.parse_args()

target_url = args.url

# ex29
paths_to_check = ["/", "/robots.txt", "/sitemap.xml"]
rezultate_paths = webtools.check_paths(target_url, paths_to_check)

with open("report.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["path", "status", "checked_at"])
    now = datetime.now().isoformat()
    for path, st in rezultate_paths.items():
        writer.writerow([path, st, now])
print("Salvat în report.csv")

# ex50 (dupa idee aici ar trebui sa se genereze raporturile)
webtools.site_report(target_url)